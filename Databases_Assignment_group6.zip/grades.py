
#pip install PrettyTable
import psycopg
from prettytable import PrettyTable
import matplotlib.pyplot as plt

conn = psycopg.connect("""
  dbname=
  user=
  password=
  host=dbm.fe.up.pt
  port=5433
  options='-c search_path=schema'
  """)
cur = conn.cursor()

cur.execute("SET search_path TO grades")

#------------ONE---------------
def search_student(first_name, last_name):
    first_name = first_name[0].upper() + first_name[1:].lower()
    last_name = last_name[0].upper() + last_name[1:].lower()

    cur.execute("SELECT * FROM student Where first_name = %s and last_name = %s",(first_name, last_name,))
    outcome = cur.fetchall()
    
    if outcome:
        column_names = [desc[0] for desc in cur.description]
        table = PrettyTable(column_names)
        for fila in outcome:
            table.add_row(fila)
        print(table)
    else:
            print("This student was not found:", first_name,"",last_name)


#------------TWO-----------------
def best_State():
    
    cur.execute("Select state, Round(Avg(gpa),2) as average_gpa from student a inner join takes b on a.student_id = b.student_id Group by state Order by Avg(gpa) desc")
    outcome = cur.fetchall()
    
    if outcome:
        column_names = [desc[0] for desc in cur.description]
        table = PrettyTable(column_names)
        for fila in outcome:
            table.add_row(fila)
        print(table)  

#------------THREE---------------
def search_exam(first_name, last_name):
    first_name = first_name[0].upper() + first_name[1:].lower()
    last_name = last_name[0].upper() + last_name[1:].lower()

    cur.execute("Select c.exam_date, d.course_name, c.exam_name, a.grade From takes a inner join student b on a.student_id = b.student_id inner join exam c on a.exam_id = c.exam_id inner join course d on c.course_id = d.course_id Where first_name = %s and last_name = %s Order by exam_date",(first_name, last_name,))
    outcome = cur.fetchall()
    
    if outcome:
        column_names = [desc[0] for desc in cur.description]
        table = PrettyTable(column_names)
        for fila in outcome:
            table.add_row(fila)
        print(table)
    else:
            print("This student was not found:", first_name,"",last_name)


#------------ THREE - EXAM DETAILS ---------------
def exam_detail(first_name, last_name):
    first_name = first_name[0].upper() + first_name[1:].lower()
    last_name = last_name[0].upper() + last_name[1:].lower()

    cur.execute("Select c.exam_name, c.exam_date, e.room_name, e.building_name, e.capacity, e.has_projector, e.has_computers, e.is_accessible From takes a inner join student b on a.student_id = b.student_id inner join exam c on a.exam_id = c.exam_id inner join located d on c.exam_id = d.exam_id inner join room e on e.room_id = d.room_id  Where first_name = %s and last_name = %s Order by exam_date",(first_name, last_name,))
    outcome = cur.fetchall()
    
    if outcome:
        column_names = [desc[0] for desc in cur.description]
        table = PrettyTable(column_names)
        for fila in outcome:
            table.add_row(fila)
        print(table)

#----------------- FOURD ------------------------
def best_student(course):
    course = course.title()

    cur.execute(" WITH RankedGrades AS (SELECT b.first_name, b.last_name,d.course_name,a.grade,ROW_NUMBER() OVER (PARTITION BY d.course_name ORDER BY a.grade DESC) AS RowNum FROM takes a INNER JOIN student b ON a.student_id = b.student_id INNER JOIN exam c ON a.exam_id = c.exam_id INNER JOIN course d ON c.course_id = d.course_id) SELECT first_name, last_name, course_name,grade FROM RankedGrades WHERE RowNum = 1 and course_name = %s",(course,))
    outcome = cur.fetchall()
    
    if outcome:
        column_names = [desc[0] for desc in cur.description]
        table = PrettyTable(column_names)
        for fila in outcome:
            table.add_row(fila)
        print(table)

#----------------- FIFTH ------------------------
def search_room(projector, computers, accessible):
    projector = projector.upper()
    computers = computers.upper()
    accessible = accessible.upper()

    cur.execute("Select * From room where has_projector = %s and has_computers = %s and is_accessible = %s",(projector,computers, accessible,))
    outcome = cur.fetchall()
    
    if outcome:
        column_names = [desc[0] for desc in cur.description]
        table = PrettyTable(column_names)
        for fila in outcome:
            table.add_row(fila)
        print(table)
    else:
        print("There aren't information about rooms that meet your requirements.")

#----------------- SEXTH ------------------------

def graph1():
    
    cur.execute("""
    SELECT exam.exam_name ,  room.room_name
    FROM exam, located,room
    WHERE exam.exam_id = located.exam_id AND room.room_id = located.room_id
    """)
    results = cur.fetchall()

    exam_name = [row[0] for row in results]
    room_name = [row[1] for row in results]
    
    plt.figure(figsize=(12, 6))
    plt.bar(exam_name, room_name, color='skyblue')
    plt.xlabel('Exam')
    plt.ylabel('Room')
    plt.title('Exam vs Room')
    plt.grid(axis='x', linestyle='--', alpha=0.8)
    plt.tight_layout()
    
    return(plt.show())
     
#----------------- SEVENTH ------------------------
def graph2(first_name, last_name):
    
    first_name = first_name[0].upper() + first_name[1:].lower()
    last_name = last_name[0].upper() + last_name[1:].lower()

    cur.execute("""
        SELECT exam.exam_date, takes.grade
        FROM exam
        INNER JOIN takes ON takes.exam_id = exam.exam_id
        INNER JOIN student ON takes.student_id = student.student_id
        WHERE student.first_name = %s AND student.last_name = %s
        ORDER BY exam.exam_date
    """, (first_name,last_name,))

    # Fetch the date and grade data
    data = cur.fetchall()
    dates = [row[0] for row in data]
    grades = [row[1] for row in data]

    # Create a line plot for grade evolution
    plt.figure(figsize=(12, 6))
    plt.plot(dates, grades, marker='o', linestyle='-', color='b')
    plt.xlabel('Exam Date')
    plt.ylabel('Grade')
    plt.title('Grade Evolution for Student ' + first_name + ' ' + last_name)
    plt.grid(axis='y', linestyle='--', alpha=0.7)
    plt.xticks(rotation=45)
    plt.tight_layout()
    return(plt.show())

#----------------- EIGHTH ------------------------
def graph3(course_name):
    course_name = course_name.title()

    # Retrieve the grades for the specified course
    cur.execute("""
        SELECT grade
        FROM takes
        INNER JOIN student ON takes.student_id = student.student_id
        INNER JOIN enrolled ON student.student_id = enrolled.student_id
        INNER JOIN course ON enrolled.course_id = course.course_id
        WHERE course.course_name = %s AND grade IS NOT NULL
    """, (course_name,))

    # Fetch the grades data
    grades = [row[0] for row in cur.fetchall()]

    # Create a histogram
    plt.figure(figsize=(10, 6))
    plt.hist(grades, bins=10, edgecolor='k', alpha=0.7)
    plt.xlabel('Grades')
    plt.ylabel('Number of Students')
    plt.title(f'Grade Histogram for {course_name}')
    plt.grid(axis='y', linestyle='--', alpha=0.7)
    return(plt.show())



print( '[1] Search for information about each student ')
print( '[2] Average gpa by state ')
print( '[3] Search for exam information about each student ')
print( '[4] Best exam for each course ')
print( '[5] Search a room with specific ')
print( '[6] Graph Exam vs Room ')
print( '[7] Graph Grade Evolution for Student ')
print( '[8] Retrieve the grades for the specified course ')
print( '[9] Exit ')

t = True

while t == True:
    
    option = input("\nChoose an option:")
    
#1. Search Student
    if option == "1":
        first = input("Student First Name: ")
        last = input("Student Last Name: ")
        print("Here is the information of",first[0].upper() + first[1:].lower(), last[0].upper() + last[1:].lower(),":")
        search_student(first, last)

#2. Best State:
    if option == "2":
        print("Average gpa by state:")
        best_State()
       
#3. Search exam
    if option == "3":
        first = input("Student First Name: ")
        last = input("Student Last Name: ")
        print("Here are the grades of",first[0].upper() + first[1:].lower(), last[0].upper() + last[1:].lower(),":")
        search_exam(first, last)

        decision = input("Do you want to see exam details? (Yes/No)")
        if decision.lower() == "yes":
            exam_detail(first, last)
        
#4. Best Exam (Best exam for each course)
    if option == "4":
        course = input("Course Name: ")
        course = course.title()
        print("This is the best exam from",course,"course:")
        best_student(course)
        
#5. Search Room
    if option == "5":
        projector = input("Do you need a projector?(True/false): ")
        computers = input("Do you need computers?(True/false): ")
        accessible = input("IDo you need it to be accessible?(True/false): ")
        print("Here is information about rooms that meet your requirements:")
        search_room(projector, computers, accessible)

#6. Graph 1 (Exam vs Room)
    if option == "6":
        graph1()

#7. Graph 2 (Grade Evolution for Student)
    if option == "7":
        first = input("Student First Name: ")
        last = input("Student Last Name: ")
        graph2(first, last)

#8. Graph 3 (Retrieve the grades for the specified course)  
    if option == "8":
            course = input("Course Name: ")
            course = course.title()
            graph3(course)

#9. Exit and close 
    if option == "9":
        cur.close()
        conn.close()
        t = False
