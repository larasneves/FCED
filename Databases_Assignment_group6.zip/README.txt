README file - This file contains a brief description of what was done and the contribution of each group member

Group 6: Helena Costa, José Mayorga, Lara Neves

To kick off our assignment, each team member individually crafted UML diagrams and relational models. Subsequently, we reunited for a collaborative meeting to compare and consolidate our individual efforts, culminating in the creation of the final diagram and model.

During this meeting, we dedicated time to data analysis. Through this process, we confirmed that there are 30 unique emails, corresponding to 30 distinct students. We also confirmed the absence of null values, ensured that each course had at least one exam (or more), and identified instances of multiple exams occurring on the same day in the same room, employing different methodologies.

Following this, Lara and Helena created an SQL script to create the database and executed it in the PostgreSQL environment. Subsequently, all code and text files were uploaded to a shared platform, enabling real-time access and synchronization of information for all team members.
Following the changes in the teacher's original CSV file, our team convened to reevaluate our UML diagrams, relational models, and SQL code.

Lara started on the task of preparing and putting the information from the CSV to the SQL database using Python, ensuring that no data was repeated, and primary keys were automatically assigned. 
Subsequently, Helena took charge of the intricate relationships between tables, ensuring a streamlined database structure and avoiding redundancy. Concurrently, Jose did the Python script to enhance user interaction, making the database more user-friendly.

During this process we faced a lot of errors which took a lot of time to understand and fix. We had to rewrite the code relations a few times but eventually we did it!

In the final phase, we improved the user interface by generating insightful visualizations, such as plots illustrating various variables, to enrich our project.

