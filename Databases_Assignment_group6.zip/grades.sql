CREATE TABLE student (
    student_id SERIAL PRIMARY KEY,
    first_name VARCHAR NOT NULL,
    last_name VARCHAR NOT NULL,
    email VARCHAR NOT NULL UNIQUE,
    date_of_birth DATE NOT NULL,
    gpa DECIMAL(3, 2) NOT NULL,
    state VARCHAR
);

CREATE TABLE course (
    course_id SERIAL PRIMARY KEY,
    course_name VARCHAR NOT NULL
);

CREATE TABLE enrolled (
    student_id INTEGER,
    course_id INTEGER,
    PRIMARY KEY (student_id, course_id),
    FOREIGN KEY (student_id) REFERENCES student(student_id),
    FOREIGN KEY (course_id) REFERENCES course(course_id)
);

CREATE TABLE room (
    room_id SERIAL PRIMARY KEY,
    room_name VARCHAR NOT NULL,
    building_name VARCHAR NOT NULL,
    capacity INTEGER,
    has_projector BOOLEAN,
    has_computers BOOLEAN,
    is_accessible BOOLEAN
);

CREATE TABLE exam (
    exam_id SERIAL PRIMARY KEY,
    course_id INTEGER REFERENCES course(course_id),
    exam_name VARCHAR NOT NULL,
    exam_date DATE NOT NULL
);

CREATE TABLE takes (
    student_id INTEGER,
    exam_id INTEGER,
    grade DECIMAL(5, 2),
    PRIMARY KEY (student_id, exam_id),
    FOREIGN KEY (student_id) REFERENCES student(student_id),
    FOREIGN KEY (exam_id) REFERENCES exam(exam_id)
);

CREATE TABLE located (
    room_id INTEGER,
    exam_id INTEGER,
    PRIMARY KEY (room_id, exam_id),
    FOREIGN KEY (room_id) REFERENCES room(room_id),
    FOREIGN KEY (exam_id) REFERENCES exam(exam_id)
);

