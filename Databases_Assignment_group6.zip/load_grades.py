
import csv
import psycopg
conn = psycopg.connect("""
  dbname=
  user=
  password=
  host=dbm.fe.up.pt
  port=5433
  options='-c search_path=schema'
  """)

cur = conn.cursor()

cur.execute("SET search_path TO grades")

# Delete all rows from all tables
cur.execute("DELETE FROM enrolled")
cur.execute("DELETE FROM located")
cur.execute("DELETE FROM takes")
cur.execute("DELETE FROM room")
cur.execute("DELETE FROM exam")
cur.execute("DELETE FROM student")
cur.execute("DELETE FROM course")

grades1 = open('grades.csv', 'r')
grades = csv.DictReader(grades1)

for row in grades:
    if any(row.values()):  
        cur.execute(
            """
            INSERT INTO student (first_name, last_name, email, date_of_birth, gpa, state)
            SELECT %s, %s, %s, %s, %s, %s
            WHERE NOT EXISTS (
                SELECT 1 FROM student WHERE email = %s
            )
            """,
            (
                row['first_name'],
                row['last_name'],
                row['email'],
                row['date_of_birth'],
                float(row['gpa']),
                row['state'],
                row['email'],
            )
        )
        conn.commit()

        course_name = row['course_name']
        cur.execute(
            """
            SELECT course_id FROM course WHERE course_name = %s
            """,
            (course_name,)
        )
        existing_course = cur.fetchone()

        if existing_course:
            course_id = existing_course[0]
        else:
            cur.execute(
                """
                INSERT INTO course (course_name)
                VALUES (%s)
                RETURNING course_id
                """,
                (course_name,)
            )
            course_id = cur.fetchone()[0]

        room_name = row['room_name']
        building_name = row['building_name']
        cur.execute(
            """
            SELECT room_id FROM room WHERE room_name = %s AND building_name = %s
            """,
            (room_name, building_name)
        )
        existing_room = cur.fetchone()

        if existing_room:
            room_id = existing_room[0]
        else:

            cur.execute(
                """
                INSERT INTO room (room_name, building_name, capacity, has_projector, has_computers, is_accessible)
                VALUES (%s, %s, %s, %s, %s, %s)
                RETURNING room_id
                """,
                (
                    room_name,
                    building_name,
                    int(row['capacity']),
                    row['has_projector'] == 't',
                    row['has_computers'] == 't',
                    row['is_accessible'] == 't'
                )
            )
            room_id = cur.fetchone()[0]
        conn.commit()

        exam_name = row['exam_name']
        exam_date = row['exam_date']        
        course_name = row['course_name']

        cur.execute(
            """
            SELECT exam_id FROM exam WHERE exam_name = %s AND exam_date = %s
            """,
            (exam_name, exam_date)
        )
        existing_exam = cur.fetchone()
        

        cur.execute(
             """
            INSERT INTO exam (exam_name, exam_date,course_id)
            VALUES (%s, %s,%s)
            RETURNING exam_id
            """,
            (exam_name, exam_date,course_id)
         )
        exam_id = cur.fetchone()[0]

        
        email = row['email']
        course_name = row['course_name']

        cur.execute(
                    """
                    SELECT student_id
                    FROM student
                    WHERE email = %s
                    """,
                    (email,)
                    )
        student_id = cur.fetchone()[0]

        cur.execute(
                    """
                    SELECT course_id
                    FROM course
                    WHERE course_name = %s
                    """,
                    (course_name,)
                    )
        course_id = cur.fetchone()[0]

        cur.execute(
                """
                SELECT 1
                FROM enrolled
                WHERE student_id = %s AND course_id = %s
                """,
                (student_id, course_id)
                )
        existing_relation = cur.fetchone()

        if not existing_relation:

            cur.execute("""
                        INSERT INTO enrolled (student_id, course_id)
                        VALUES (%s, %s)
                        """, (student_id, course_id))
           
        else:
            print(f"The relation between student_id {student_id} and course_id {course_id} already exists in enrolled.")
            
            
        room_name = row['room_name']
        exam_name = row['exam_name']
        
        cur.execute(
            """
            SELECT room_id
            FROM room
            WHERE room_name = %s
            """,
            (room_name,)
        )
        room_id = cur.fetchone()

        cur.execute(
            """
            SELECT exam_id
            FROM exam
            WHERE exam.exam_name = %s AND exam_date = %s
            """,
            (exam_name,exam_date)
        )
        exam_id = cur.fetchone()

        if room_id and exam_id:
            room_id = room_id[0]
            exam_id = exam_id[0]

            cur.execute(
                """
                SELECT 1
                FROM located
                WHERE room_id = %s AND exam_id = %s
                """,
                (room_id, exam_id)
            )
            existing_relation = cur.fetchone()

            if not existing_relation:
                cur.execute(
                    """
                    INSERT INTO located (room_id, exam_id)
                    VALUES (%s, %s)
                    """,
                    (room_id, exam_id)
                )
                conn.commit()
            else:
                print(f"The relation between room_id {room_id} and exam_id {exam_id} already exists in located.")

        email = row['email']
        exam_name = row['exam_name']
        grade=float(row['grade'])

        cur.execute(
                        """
                        SELECT student_id
                        FROM student
                        WHERE email = %s
                        """,
                        (email,)
                        )
        student_id = cur.fetchone()[0]

        cur.execute(
                        """
                        SELECT exam_id
                        FROM exam
                        WHERE exam_name = %s AND exam_date = %s
                        """,
                        (exam_name,exam_date)
                        )
        exam_id = cur.fetchone()[0]
            
        cur.execute(
                        """
                        SELECT 1
                        FROM takes
                        WHERE student_id = %s AND exam_id = %s
                        """,
                        (student_id, exam_id)
                        )
        existing_relation = cur.fetchone()

        if not existing_relation:
                        
         
                    cur.execute("""
                            INSERT INTO takes (student_id, exam_id, grade)
                            VALUES (%s, %s, %s)
                            """, (student_id, exam_id, grade))
                    conn.commit()
        else:
            print(f"The relation between student_id {student_id} and exam_id {exam_id} already exists in takes.")

    conn.commit()
    print("done")
